import re
import streamlit as st
import matplotlib.pyplot as plt
from fpdf import FPDF
import os
import pandas as pd
from datetime import datetime
import csv
import base64
from io import BytesIO
from fpdf import FPDF
from PyPDF2 import PdfReader, PdfWriter
from PIL import Image

# Function to log queries to a CSV file
def log_query_to_csv(user_query, sql_query, csv_file='query_log.csv'):
    # Check if the file exists
    file_exists = os.path.isfile(csv_file)
    
    # Get the current timestamp
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    # Open the file in append mode
    with open(csv_file, mode='a', newline='') as file:
        writer = csv.writer(file)
        
        # Write the header if the file doesn't exist
        if not file_exists:
            writer.writerow(['Timestamp', 'User Query', 'SQL Query'])
        
        # Write the data
        writer.writerow([timestamp, user_query, sql_query])

def load_log_csv(csv_file='query_log.csv'):
    try:
        return pd.read_csv(csv_file)
    except FileNotFoundError:
        # If the file does not exist, return an empty DataFrame
        return pd.DataFrame(columns=['Timestamp', 'User Query', 'SQL Query'])
    
def extract_natural_language_response(response_text):
    # response_pattern = r'(.*?)(?: Python Code to Create a Visualization|And here is the Seaborn code to visualize the response:|Seaborn code|```)'
    # response_pattern = r'(.*?)### 2\. Python Code for Visualization'
    response_pattern = r'(.*?)(?:\*\*2|Python Code for Visualization:|Python code|Visualization|```)'
    natural_language_response = re.search(response_pattern, response_text, re.DOTALL | re.IGNORECASE)
    if natural_language_response:
        return str(natural_language_response.group(1).strip())
    else:
        return None

def extract_code_snippet(response_text):
    code_pattern = r'```(.*?)\n(.*?)```'
    
    code_snippet = re.search(code_pattern, response_text, re.DOTALL | re.IGNORECASE)
    if code_snippet:
        return code_snippet.group(2).strip()
    else:
        return None
def generate_csv(user_query, generated_sql_query, csv_path='output.csv'):
    df = pd.DataFrame({
        'User Query': [user_query],
        'Generated SQL Query': [generated_sql_query]
    })
    df.to_csv(csv_path, index=False)
    return csv_path

def generate_pdf(question, natural_language_response, image_path=None, pdf_path='output.pdf'):
    # Create a new PDF with the question and response
    new_pdf = FPDF()
    new_pdf.add_page()
    new_pdf.add_font('Cambria', '', 'cambria.ttf', uni=True)
    new_pdf.set_font("Cambria", size=10)  # Change font to Cambria
    line_height = 4  # Adjust line height to reduce space between lines
    
    # Add question
    new_pdf.multi_cell(0, line_height, f"Question:\n{question}\n", align='J')
    
    # Add natural language response
    new_pdf.multi_cell(0, line_height, f"Response:\n{natural_language_response}\n", align='J')
    
    # Add image if provided
    if image_path and os.path.exists(image_path):
        
#         with Image.open(image_path) as img:
#             image_width, image_height = img.size
#         # Calculate the x and y coordinates for center alignment
#         x = (new_pdf.w - image_width) / 2
#         y = new_pdf.get_y()

#         # Check if the image fits on the current page
#         if y + image_height > new_pdf.h:
#             new_pdf.add_page()

#         # Add the image to the PDF
#         new_pdf.image(image_path, x, y, w=100, h=100)
        
        
        
        new_pdf.image(image_path, x=5, y=new_pdf.get_y(), w=150, h=80)
    
    # Save the new PDF content to a temporary file
    temp_pdf_path = "temp_output.pdf"
    new_pdf.output(temp_pdf_path)
    
    # Read the existing PDF (if it exists)
    writer = PdfWriter()
    if os.path.exists(pdf_path):
        reader = PdfReader(pdf_path)
        for page in reader.pages:
            writer.add_page(page)
    
    # Add the new content to the existing PDF
    new_reader = PdfReader(temp_pdf_path)
    for page in new_reader.pages:
        writer.add_page(page)
    
    # Save the combined PDF
    with open(pdf_path, 'wb') as output_pdf:
        writer.write(output_pdf)
    
    # Remove the temporary file
    os.remove(temp_pdf_path)
    
    return pdf_path
def run_code_snippet(code, image_path='plot.png'):
    try:
        exec(code)
        plt.savefig(image_path)
        plt.close()
        with open(image_path, "rb") as image_file:
            img_str = base64.b64encode(image_file.read()).decode('utf-8')
        return img_str
    except Exception as e:
        print(f"Error occurred while executing the code snippet:\n{e}")
        return None
    
def erase_pdf(pdf_path='output.pdf'):
    if os.path.exists(pdf_path):
        os.remove(pdf_path)
        print(f"{pdf_path} has been erased.")
    else:
        print(f"{pdf_path} does not exist.")

def main(response_text):
    # Define keywords to search for in code snippets
    search_words = ['python', 'seaborn', 'visualize', 'import']

    
    code_snippet = extract_code_snippet(response_text)

    

    if code_snippet:
        print("\nPython Code Snippet:")
        print(code_snippet) 
        
        # Run the code snippet and get the image path
        print("\nRunning Python Code Snippet...")
        
        image_path = run_code_snippet(code_snippet)
        return image_path

    return None
