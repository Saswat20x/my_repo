#Get SQL Chain
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_community.utilities import SQLDatabase
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_groq import ChatGroq

# Initialize the LLM
groq_api_key = "**************************************"
llm = ChatGroq(groq_api_key=groq_api_key, model="llama3-70b-8192", temperature=0)

def get_sql_chain(db):
    """
    This function generates a SQL query based on the user's question and the provided table schema.

    Args:
        db (SQLDatabase): The database object.

    Returns:
        A Complete prompt that can be used to generate a SQL query using LLM.
    """
    template = """
    You are a helpful sales and marketing officer at a company. You are interacting with a user who is asking you questions 
    about the marketing research database. Based on the table schema below, write a MySQL-compatible SQL query 
    that would answer the user's question.

    <SCHEMA>{schema}</SCHEMA>

    Important Instructions:
        Ensure that you should write SQL query only for DQL (Data Query Language) commands.
        Never ever write SQL query those falls under DML (Data Manipulation Language) and DCL (Data Control Language) commands.
        Write only the SQL query and nothing else.
        Never ever include any text, markdown code fences, backticks, or quotes around the SQL query.
        Ensure the SQL query is compatible with MySQL.

    For example:
        Question: What is the total revenue from sales of product 1?
        SQL Query:  SELECT SUM(Revenue) 
                    FROM sales_data 
                    WHERE ProductId = 1;

        Question: Which customers belong to segment 1?
        SQL Query: SELECT c.FirstName, c.LastName 
                    FROM customers c 
                    JOIN customer_segments cs ON c.CustomerId = cs.CustomerId 
                    WHERE cs.SegmentId = 1;

        Question: What are the names of all advertising channels?
        SQL Query: SELECT ChannelName FROM advertising_channels;

        Your turn:
        Question: {question}
        SQL Query:
    """
    
    prompt = ChatPromptTemplate.from_template(template)
  #Get Schemas
    def get_schema(_):
        return db.get_table_info()
    return (
    RunnablePassthrough.assign(schema=get_schema)
    | prompt
    | llm
    | StrOutputParser()
            )


#Generate SQL Query and Write result to Local CSV file
def get_llm_response(user_query, db):
    """
    This function generates a SQL query based on the user's question and the table schema using LLM, and saves the query to a CSV file.

    Args:
        user_query (str): The user's question.
        db (SQLDatabase): The database object.

    Returns:
        The LLM generated SQL query.
    """
    sql_chain = get_sql_chain(db)
    schema = db.get_table_info()
    sql_query = sql_chain.invoke({'question': user_query, 'schema': schema})
    
    # Define the CSV file name and path
    csv_file_name = 'llm_responses.csv'
    csv_file_path = './' + csv_file_name
    
    # Check if the CSV file exists, if not create it with headers
    if not os.path.exists(csv_file_path):
        with open(csv_file_path, 'w', newline='') as csvfile:
            fieldnames = ['user_query', 'sql_query', 'date_time']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
    
    # Append new values to the CSV file
    with open(csv_file_path, 'a', newline='') as csvfile:
        fieldnames = ['user_query', 'sql_query', 'date_time']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writerow({
            'user_query': user_query,
            'sql_query': sql_query,
            'date_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })
    return sql_query

def second_llm(dataframe, question):
    """
    This function converts the dataframe to natural language and generates a JSON object for plotting the response.

    Args:
        dataframe (pandas.DataFrame): The dataframe.
        question (str): The user's question.

    Returns:
        The converted natural language and JSON object.
    """
    # Define the prompt template
    template = """
    You are a helpful analyst at a company. Based on the dataframe provided below,
    <DATAFRAME>{dataframe}</DATAFRAME>
    Important Instructions:
        A)Dataframe is the answer for <QUESTION>{question}</QUESTION>, convert it in Natural Langauge.Make proper, grammatical correct and two simple sentences only.
        B)Generate a JSON object that includes the following details:
            - Convert dataframe in json format as body.
            - Identify the appropriate primaryChart based on the dataframe (choose chart type any one from list ["area","bubble","pie","scatter"])
            - Identify the appropriate secondaryChart based on the dataframe (choose chart type any one from list ["area","bar","bubble","pie","line","scatter"])
            - Identify the label for the x-axis from the dataframe
            - Identify the label for the y-axis from the dataframe
            - If you don't know the answer just return "Plot not possible"
        C)Never include any text or explaination.
    """
    prompt = ChatPromptTemplate.from_template(template)
    chain = prompt | llm
    # question="How many sales were made for top 5 products?"
    input_content = {
        'dataframe': dataframe,'question':question
    }
    output=chain.invoke(input_content)
    return output.content

#Generate Final Result
from flask import Flask, request, jsonify
import pandas as pd
from sqlalchemy import create_engine

app = Flask(__name__)

def generate_result(user_query):
    """
    Generate results based on the user's SQL query.

    This function takes a user-provided query, generates a corresponding SQL query,
    executes it against a SQLite database, and processes the results using a language model.

    Parameters:
    user_query (str): The query provided by the user.

    Returns:
    tuple: A tuple containing:
        - final_response (str): The processed response from the language model.
        - generated_sql_query (str): The SQL query generated from the user query.
        - dataframe_json (str): The results of the SQL query in JSON format.
    """
    database_path = "sqlite:///marketing_research_database.db"
    
    # Initialize Database
    db = SQLDatabase.from_uri(database_path)
    
    # Create a SQLAlchemy engine
    engine = create_engine(database_path)
    
    # Generate SQL Query through LLM
    generated_sql_query = get_llm_response(user_query, db)
    final_response = ""
    dataframe = ""

    try:
        # Run the query and store the results in a DataFrame
        dataframe = pd.read_sql_query(generated_sql_query, engine)
        final_response = second_llm(dataframe, user_query)
        return final_response, generated_sql_query, dataframe.to_json(orient="columns")
    except Exception as e:
        # Handle exceptions and return appropriate values
        return final_response, generated_sql_query, dataframe

@app.route('/generate_result', methods=['GET'])
def run_generate_result():
    """
    Endpoint to generate results based on user query.

    This endpoint accepts a user query as a URL parameter, invokes the 
    generate_result function, and returns the results in JSON format.

    Returns:
    JSON response containing:
        - result1 (str): The processed response from the language model.
        - result2 (str): The generated SQL query.
        - result3 (str): The results of the SQL query in JSON format.
    """
    user_query = request.args.get('user_query')
    result1, result2, result3 = generate_result(user_query)
    return jsonify({'result1': result1, 'result2': result2, 'result3': result3})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80, debug=False)