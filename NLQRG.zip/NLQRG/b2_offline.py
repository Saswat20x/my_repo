from transformers import pipeline
import sqlparse

# Create a pipeline for text generation
pipe = pipeline("text-generation", model="./sql_coder_llm")

# Define the prompt template
prompt_template = """
### Task
- You are a helpful sales and marketing officer at a company. You are interacting with a user who is asking you questions about the marketing research database. Based on the table schema below, write a MySQL-compatible SQL query that would answer the user's question.

### Instructions:
- Ensure that you should write SQL query only for DQL (Data Query Language) commands.
- Never ever write SQL query those falls under DML (Data Manipulation Language) and DCL (Data Control Language) commands.
- Write only the SQL query and nothing else.
- Never ever include any text, markdown code fences, backticks, or quotes around the SQL query.
- Ensure the SQL query is compatible with MySQL.
- If you cannot answer the question with the available database schema, return 'I don't know'

### Database Schema
This query will run on a database whose schema is represented in this string:
CREATE TABLE campaigns (
    CampaignId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    CampaignName NVARCHAR(50) NOT NULL,
    StartDate DATETIME NOT NULL,
    EndDate DATETIME NOT NULL,
    Budget REAL NOT NULL
)

CREATE TABLE customers (
    CustomerId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    FirstName NVARCHAR(20) NOT NULL,
    LastName NVARCHAR(20) NOT NULL,
    Email NVARCHAR(60) NOT NULL,
    Phone NVARCHAR(20),
    Address NVARCHAR(70)
)

CREATE TABLE customer_responses (
    ResponseId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    CampaignId INTEGER NOT NULL,
    CustomerId INTEGER NOT NULL,
    ResponseDate DATETIME NOT NULL,
    Response NVARCHAR(200),
    FOREIGN KEY (CampaignId) REFERENCES campaigns (CampaignId),
    FOREIGN KEY (CustomerId) REFERENCES customers (CustomerId)
)

CREATE TABLE market_segments (
    SegmentId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    SegmentName NVARCHAR(30) NOT NULL,
    Description NVARCHAR(100)
)

CREATE TABLE customer_segments (
    CustomerId INTEGER NOT NULL,
    SegmentId INTEGER NOT NULL,
    PRIMARY KEY (CustomerId, SegmentId),
    FOREIGN KEY (CustomerId) REFERENCES customers (CustomerId),
    FOREIGN KEY (SegmentId) REFERENCES market_segments (SegmentId)
)

CREATE TABLE products (
    ProductId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    ProductName NVARCHAR(50) NOT NULL,
    Description NVARCHAR(100),
    Price REAL NOT NULL
)

CREATE TABLE product_responses (
    ResponseId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    ProductId INTEGER NOT NULL,
    CustomerId INTEGER NOT NULL,
    ResponseDate DATETIME NOT NULL,
    Response NVARCHAR(200),
    FOREIGN KEY (ProductId) REFERENCES products (ProductId),
    FOREIGN KEY (CustomerId) REFERENCES customers (CustomerId)
)

CREATE TABLE advertising_channels (
    ChannelId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    ChannelName NVARCHAR(30) NOT NULL,
    Description NVARCHAR(100)
)

CREATE TABLE campaign_channels (
    CampaignId INTEGER NOT NULL,
    ChannelId INTEGER NOT NULL,
    PRIMARY KEY (CampaignId, ChannelId),
    FOREIGN KEY (CampaignId) REFERENCES campaigns (CampaignId),
    FOREIGN KEY (ChannelId) REFERENCES advertising_channels (ChannelId)
)

CREATE TABLE sales_data (
    SaleId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    ProductId INTEGER NOT NULL,
    CustomerId INTEGER NOT NULL,
    SaleDate DATETIME NOT NULL,
    Quantity INTEGER NOT NULL,
    Revenue REAL NOT NULL,
    FOREIGN KEY (ProductId) REFERENCES products (ProductId),
    FOREIGN KEY (CustomerId) REFERENCES customers (CustomerId)
)

CREATE TABLE distribution_channels (
    ChannelId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    ChannelName NVARCHAR(30) NOT NULL,
    Description NVARCHAR(100)
)

CREATE TABLE product_distribution (
    ProductId INTEGER NOT NULL,
    ChannelId INTEGER NOT NULL,
    PRIMARY KEY (ProductId, ChannelId),
    FOREIGN KEY (ProductId) REFERENCES products (ProductId),
    FOREIGN KEY (ChannelId) REFERENCES distribution_channels (ChannelId)
)

CREATE TABLE public_relations (
    PRId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    PRType NVARCHAR(20) NOT NULL,
    Description NVARCHAR(100),
    Date DATETIME NOT NULL
)

CREATE TABLE pr_campaigns (
    PRId INTEGER NOT NULL,
    CampaignId INTEGER NOT NULL,
    PRIMARY KEY (PRId, CampaignId),
    FOREIGN KEY (PRId) REFERENCES public_relations (PRId),
    FOREIGN KEY (CampaignId) REFERENCES campaigns (CampaignId)
)

### Answer
Given the database schema, here is the SQL query that answers [QUESTION]{question}[/QUESTION]
[SQL]
"""

def generate_sql_query(question):
    """
    Generates a MySQL-compatible SQL query based on a user's question and the provided database schema.
    Args:
        question (str): The user's question regarding the marketing research database.
    Returns:
        str: The generated SQL query, formatted for readability. If the question cannot be answered based on the schema,
              returns 'I don't know'.
    """
    # Replace the placeholder in the prompt template with the actual question
    prompt = prompt_template.replace("{question}", question)
    # Generate text using the pipeline
    output = pipe(prompt, max_new_tokens=500)[0]['generated_text']
    # Extract and format the SQL query from the generated text
    sql_query = sqlparse.format(output.split('[SQL]')[1], reindent=True)
    return sql_query

import csv
from datetime import datetime
import os

def get_llm_response(user_query, db):
    """
    Generates a SQL query based on the user's query, logs the query along with the original user query
    and the current date and time into a CSV file.
    Args:
        user_query (str): The user's question for which the SQL query needs to be generated.
        db (object): An object that provides database schema information via the `get_table_info` method.
    Returns:
        str: The generated SQL query.
    """
    # Obtain the database schema information (not used directly in this function)
    schema = db.get_table_info()
    # Generate SQL query based on the user's query
    sql_query = generate_sql_query(user_query)
    # Define the CSV file name and path
    csv_file_name = 'sql_coder_llm_responses.csv'
    csv_file_path = './' + csv_file_name
    # Check if the CSV file exists, if not create it with headers
    if not os.path.exists(csv_file_path):
        with open(csv_file_path, 'w', newline='') as csvfile:
            fieldnames = ['user_query', 'sql_query', 'date_time']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
    # Append new values to the CSV file
    with open(csv_file_path, 'a', newline='') as csvfile:
        fieldnames = ['user_query', 'sql_query', 'date_time']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writerow({
            'user_query': user_query,
            'sql_query': sql_query,
            'date_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })
    return sql_query

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_community.utilities import SQLDatabase
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_groq import ChatGroq

# Initialize the LLM
groq_api_key = "*************************"
llm = ChatGroq(groq_api_key=groq_api_key, model="llama3-70b-8192", temperature=0)

def second_llm(dataframe, question):
    """
    Generates natural language responses and JSON objects from the provided dataframe based on the given question.

    Args:
        dataframe (str): A string representation of the dataframe to be used for generating responses.
        question (str): A question related to the dataframe to guide the natural language generation.

    Returns:
        str: The generated response containing natural language, two JSON objects for ChartJS, or a message stating
             that JSON object creation is not possible.
    
    Important Instructions:
        A) Convert the dataframe into a grammatically correct and concise natural language response in two simple sentences.
        B) Create a JSON object from the dataframe for ChartJS, specifying a type of chart and using innovative plots.
        C) Generate a different JSON object from the dataframe for ChartJS, specifying a different type of chart from instruction B.
        D) If JSON object creation is not possible for instructions B and C, return "can't provide JSON object for provided data". Do not include any additional text or explanation.
    """
    # Define the prompt template
    template = """
    You are a helpful analyst at a company. Based on the dataframe provided below,
    <DATAFRAME>{dataframe}</DATAFRAME>
    Important Instructions:
        A)Dataframe is the answer for <QUESTION>{question}</QUESTION>, convert it in Natural Langauge.Make proper, grammatical correct and two simple sentences only.
        B)Generate a JSON object from above dataframe for ChartJS, use innovative plots.compulsarily include in json object the type of chart.
        C)Generate a another JSON object from above dataframe for ChartJS.compulsarily include in json object the type of chart.Dont create same like instruction B.
        D) For instruction B and C if json object creation is not possible then just say "cant provide json object for provided data".Never include any text or explaination.
    """
    prompt = ChatPromptTemplate.from_template(template)
    chain = prompt | llm
    # Prepare input content with the dataframe and question
    input_content = {
        'dataframe': dataframe,
        'question': question
    }
    # Invoke the chain and get the output
    output = chain.invoke(input_content)
    return output.content

from flask import Flask, request, jsonify
import pandas as pd
from sqlalchemy import create_engine

app = Flask(__name__)

def generate_result(user_query):
    """
    Generates a response based on the user query by executing a generated SQL query on the database
    and processing the resulting dataframe with an LLM.
    Args:
        user_query (str): The user's query for which the SQL query needs to be generated and executed.
    Returns:
        str: The final response generated by processing the dataframe, or the SQL query if an error occurs.
    """
    database_path="sqlite:///marketing_research_database.db"
    #Initialize Database
    db = SQLDatabase.from_uri(database_path)
    # Create a SQLAlchemy engine
    engine = create_engine(database_path)
    # Generate SQL Query through LLM
    generated_sql_query=get_llm_response(user_query, db)
    final_response=""
    dataframe=""
    # print(generated_sql_query)
    # dataframe = pd.read_sql_query(generated_sql_query, engine)
    # final_response=second_llm(dataframe,user_query)
    # print(final_response)
    # print(generated_sql_query)
    # print(dataframe.to_json(orient="columns"))
    # return final_response,generated_sql_query,dataframe.to_json(orient="columns")
    try:
        # Run the query and store the results in a DataFrame
        dataframe = pd.read_sql_query(generated_sql_query, engine)
        final_response=second_llm(dataframe,user_query)
        return final_response,generated_sql_query,dataframe.to_json(orient="columns")
    except:
        return final_response, generated_sql_query, dataframe

@app.route('/generate_result', methods=['GET'])
def run_generate_result():
    """
    Flask route handler for generating results based on the user query provided in the request.
    Returns:
        Response: The result of the generate_result function, which is either the processed response or the SQL query.
    """
    # Get the user query from the request parameters
    user_query = request.args.get('user_query')
    result1,result2,result3 = generate_result(user_query)
    return jsonify({'result1': result1, 'result2': result2, 'result3': result3})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80, debug=False)
