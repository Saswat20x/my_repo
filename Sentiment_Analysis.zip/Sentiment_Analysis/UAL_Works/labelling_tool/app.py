# pip install flask-login

# setup a flask app
import os, datetime, flask, re
from flask import render_template, request, redirect
from werkzeug.utils import secure_filename
import pandas as pd

app = flask.Flask(__name__)
app.secret_key = 'RuNefMorsFex'  # secret key for flask session

# set upload folder path
UPLOAD_FOLDER = "./uploads"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# Flask-Login works via a login manager
import flask_login

login_manager = flask_login.LoginManager()

login_manager.init_app(app)

# mock database
users = {
        'foo@bar.tld': {'password': 'secret',
                         'df': None,
                         'columns': None,
                         'labelled_filepath': None},
        'palash.sharma@impetus.co.in': {'password':'secret',
                         'df': None,
                         'columns': None,
                         'labelled_filepath': None}
        }

"""
We need to tell Flask-Login how to load a user from a Flask request and from its session.
To do this we need to define our user object, a user_loader callback, and a request_loader callback.
"""
class User(flask_login.UserMixin):
    pass

@login_manager.user_loader
def user_loader(email):
    if email not in users:
        return

    user = User()
    user.id = email
    return user

@login_manager.request_loader
def request_loader(request):
    email = request.form.get('email')
    if email not in users:
        return

    user = User()
    user.id = email

    # DO NOT ever store passwords in plaintext and always compare password
    # hashes using constant-time comparison!
    user.is_authenticated = request.form['password'] == users[email]['password']
    return user

"""
Now we're ready to define our views. We can start with a login view,
which will populate the session with authentication bits.
After that we can define a view that requires authentication.
"""
@app.route('/login', methods=['GET', 'POST'])
def login():
    if flask.request.method == 'GET':
        try:
            # if user already logged in then show message
            return "User already logged in as {}".format(flask_login.current_user.id)
        except:
            return render_template("login.html")

    email = flask.request.form['email']
    if email not in users.keys():
        return "Invalid User id"
    if flask.request.form['password'] == users[email]['password']:
        user = User()
        user.id = email
        flask_login.login_user(user)
        return flask.redirect(flask.url_for('protected'))

    return 'Bad login'


@app.route('/protected', methods = ["GET", "POST"])
@flask_login.login_required
def protected():
    """save the uploaded file and return acknowledgement"""
    
    # replace special characters in the username with _
    uname = re.sub('[^a-zA-Z0-9]', '_', flask_login.current_user.id)
    # create uploads/username directory
    dir_path = os.path.join(app.config["UPLOAD_FOLDER"], uname)
    unlabelled_dir = os.path.join(dir_path, "unlabelled")
    labelled_dir = os.path.join(dir_path, "labelled")

    for path_ in [dir_path, unlabelled_dir, labelled_dir]:
        if not os.path.exists(path_):
            os.makedirs(path_)
    
    if request.method == "POST":
        f = request.files["file"]

        # create filename as username_timestamp ex:(palash_yy_mm_dd_hh_mm_ss.csv)
        file_ext = secure_filename(f.filename).split(".")[-1] # get file extension
        datetime_str = re.sub("[-: ]", "_", str(datetime.datetime.now())).split(".")[0]
        filename = uname + "_" + datetime_str + "." + file_ext
        
        # save file in unlabelled directory
        filepath = os.path.join(unlabelled_dir, filename)
        print("filepath:{}".format(filepath))
        f.save(filepath)
        
        # save labelled file path for future updates in the file
        users[flask_login.current_user.id]["labelled_filepath"] = os.path.join(labelled_dir, filename)

        print("Reading {} ...".format(filepath))

        users[flask_login.current_user.id]["df"] = pd.read_csv(filepath)
        print("Done reading...\nReady to serve")

        print(users[flask_login.current_user.id]["df"].head())
        # redirect user to workspace
        return redirect("workspace/0")
    return render_template("protected.html", username= flask_login.current_user.id)

@app.route('/workspace/<index_number>', methods = ["GET", "POST"])
@flask_login.login_required
def workspace(index_number):
    """
    This will send single row to the page
    """
    print("request.method is {}, index_number is {}".format(request.method, index_number))
    if request.method == "GET":
        columns = list(users[flask_login.current_user.id]["df"].columns) # get column list from the dataframe
        columns.remove("Comments") # keep only col names which will be used for creating buttons dynamically on the html page
        # print("Recieved Index Number:{}".format(index_number))
        try:
            row_content = users[flask_login.current_user.id]["df"]["Comments"][int(index_number)]
            return render_template("workspace.html", column_list=columns, text=row_content, indx=int(index_number))
        
        except KeyError:
            return "End of Records. Go back to Download file"

    if request.method == "POST" and request.form.getlist('column_buttn') != 0:
        
        columns_to_update = request.form.getlist('column_buttn')
        labelled_file_path = users[flask_login.current_user.id]["labelled_filepath"]
        # print(columns_to_update)
        # update value of the columns
        for column in users[flask_login.current_user.id]["df"].columns:
            print(column)
            if column != "Comments":
                # get the index of the column
                col_index = users[flask_login.current_user.id]["df"].columns.get_loc(column)
                if column in columns_to_update:
                    # update value of the column to 0
                    users[flask_login.current_user.id]["df"].iloc[int(index_number), col_index] = 1
                else:
                    # update value of the column to 1
                    users[flask_login.current_user.id]["df"].iloc[int(index_number), col_index] = 0
        
        # print(users[flask_login.current_user.id]["df"])
        users[flask_login.current_user.id]["df"].to_csv(labelled_file_path)
    
        # print(columns_to_update)
        # print(index_number)
        return redirect(str(int(index_number)+1))




"""Finally we can define a view to clear the session and log users out"""

@app.route('/logout')
def logout():
    flask_login.logout_user()
    return render_template("logout.html")

"""
We now have a basic working application that makes use of session-based authentication.
To round things off, we should provide a callback for login failures
"""

@login_manager.unauthorized_handler
def unauthorized_handler():
    return render_template("unauthorized.html")

if __name__ == "__main__":
    app.run(debug=True)