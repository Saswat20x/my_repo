#General Purpose Labelling Tool


Start-Date: 01/August/2019


Team Members:
1. Palash Sharma
2. Jay Gulraj

Functionalities:
1. Login, Logout (Flask Session).
2. Upload CSV.
3. Display each row with appropriate column names checkboxes.
4. Update CSV based on the checkboxes selected.
5. CSVs are stored in the upload/username/labelled and upload/username/unlabelled directories respectively.
