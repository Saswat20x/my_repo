import streamlit as st
from langchain.llms import OpenAI
import tiktoken
import os
import numpy as np
import json




st.title('Airlines Flight Review Sentiment Analysis')
 
openai_api_key = st.sidebar.text_input('OpenAI API Key')

from langchain.llms import OpenAI
global llm
llm = None
global revdata
revdata = None

# Open the JSON file
with open("All_Reviews_Processed.json", "r") as f:
    revdata = json.load(f)  

    
    
# Prompt Start Lines, Intermediate Lines, End Lines and Questions
sl1 = "Following is a review of United Airlines flight customer:"
q1 = "Is the above text written by a flight customer a review or a feedback. Does it have any negative or positive words? Does it have any concerns explained? Answer me in 'YES' or 'NO' if it is some review"
q2 = "Answer me on a scale of -5 to 5 how good or bad this review is. -5 means very negative. 5 means very positive. Answer only in single number."
q3 = "Can you parse the above review into multiple sentences such that each sentence is complete in itself, talks about one issue and no pronouns are used? Dont use new adjectives other than mentioned in the original review. Dont exaggerate. Provide a numbered list of sentences. Do not create new sentences on your own. Use the parts from the original review."
q4 = "Can you split the above review into multiple sentences without using any pronouns and generate complete sentences?"
q5 = "Is this review talking about ASPECT? Answer me in YES or NO."
q6 = "Can you correct the spelling mistakes in the above review? If there are no spelling mistakes, just print the same exact review" 
q7 = "Can you rewrite the same sentence with coreferences resolved?"

# FEW SHOT PROMPTING

# SAMPLE EXAMPLE
examplelist = ["The food was bad and dirty Airplane was awful, looked awful",
               "Food was bad, flight delayed, poor check in"]
outputlist = [
'''
1. The food was bad and dirty
2. Airplane was awful, looked awful
''',
'''
1. Food was bad
2. Flight delayed
3. Poor check in
'''
]
sl = "Following are the " + str(len(examplelist)) + " examples:"
examplesuppline = "It should be splitted into following two sentences:"
ml = "Given the following review:"
finalq = "Can you parse the above review into multiple parts such that each sentence is complete in itself. Provide a numbered list of sentences."
placeholderkey = "#REVIEW#"


def create_few_shot_prompt(sl, examplelist, outputlist, ml, placeholderkey, finalq):
    prompt = ""
    prompt += sl + "\n"
    for i, each in enumerate(examplelist):
        prompt = prompt + str(i+1) + ". " + "'" + str(examplelist[i]) + "'" + '\n'
        prompt = prompt + examplesuppline + "\n"
        prompt = prompt + str(outputlist[i]) + "\n\n"

    prompt= prompt + ml + "\n" + placeholderkey + "\n\n"
    prompt = prompt + finalq
    return prompt

def create_final_prompt(placeholderprompt, text):
    prompt = placeholderprompt.replace(placeholderkey, text)
    return prompt

from langchain_core.messages import HumanMessage
from langchain_openai import ChatOpenAI


def get_response(prompt, technology = "gpt4_v1"):
    if technology == "gpt4_v1":
        global llm
        op = llm.invoke(
            [
                HumanMessage(
                    content=prompt
                )
            ]
        )  
        return op.content
    

def sentence_splitting(review):
    examplelist = ["The food was bad and dirty Airplane was awful, looked awful",
               "Food was bad, flight delayed, poor check in"]
    outputlist = [
    '''
    1. The food was bad and dirty
    2. Airplane was awful, looked awful
    ''',
    '''
    1. Food was bad
    2. Flight delayed
    3. Poor check in
    '''
    ]
    sl = "Following are the " + str(len(examplelist)) + " examples:"
    examplesuppline = "It should be splitted into following two sentences:"
    ml = "Given the following review:"
    finalq = "Can you parse the above review into multiple parts such that each sentence is complete in itself. Provide a numbered list of sentences. If you cannot parse, just print the original text."
    placeholderkey = "#REVIEW#"
    phprompt = create_few_shot_prompt(sl, examplelist, outputlist, ml, placeholderkey, finalq)
    prompt = create_final_prompt(phprompt, review)
    resp = get_response(prompt)
    return resp 

def is_it_a_review(review):
    prompt = "'" + review + "'" + "\n" + q1
    resp = get_response(prompt)
    if "yes" in resp.lower():
        return "YES"
    return "NO"

def remove_typos(review):
    prompt = "'" + review + "'" + "\n" + q6
    resp = get_response(prompt)
    return resp

def resolve_coreference_resolution(review):
    prompt = "'" + review + "'" + q7
    resp = get_response(prompt)
    return resp

def clean_review(singlelinereview):
    review = singlelinereview.replace("\n","")
    review = review.replace('"',"")
    return review

def contains_questions(review):
    que = "Does the above text contain any questions? Answer in YES or NO. If YES, print the numbered list of questions as well."
    prompt = "'" + review + "'" + "\n" + que
    resp = get_response(prompt)
    if " no " in resp.lower():
        return "NO"
    return resp

def contains_comparisons(review):
    que = "Does the flight customer in above text doing any comparisons of United Airlines wiith other airlines? Answer in YES or NO. If YES, print the comparisons in a numbered list."
    prompt = "'" + review + "'" + "\n" + que
    resp = get_response(prompt)
    if " no " in resp.lower():
        return "NO"
    return resp

sentexamplelist = ["The food was bad and dirty Airplane was awful, looked awful",
               "Food was bad, flight delayed, poor check in"]
sentoutputlist = [-4, -3]

def assign_sentiment_score(sentexamplelist, sentoutputlist, review):
    sl = "Following are the " + str(len(sentexamplelist)) + " examples:"
    examplesuppline = "It should be assigned the following sentiment score:"
    ml = "Given the following review:"
    finalq = q2
    placeholderkey = "#REVIEW#"
    phprompt = create_few_shot_prompt(sl, sentexamplelist, sentoutputlist, ml, placeholderkey, finalq)
    prompt = create_final_prompt(phprompt, review)
    #
    prompt = "'" + review + "'" + "\n" + q2
    resp = get_response(prompt)
    resp = "".join(c for c in resp if not c.isalpha() and c not in [',','.',' '])
    sentscore = int(resp)
    return sentscore

def rev_splits(revsplits):
    # OBTAINED THE LIST OF SUBREVIEWS FROM A REVIEW
    revsplitlist = revsplits.split("\n")
    new1revsplitlist = []
    for each in revsplitlist:
        if len(each) != 0:
            subrev = each.split(". ")[1]
            subrev = clean_review(subrev)
            new1revsplitlist.append(subrev)
    new2revsplitlist = {}
    for each in new1revsplitlist:
        # CHECKING IF THE SUBREVIEW IS A REVIEW 
        prompt = "'" + each + "'" + "\n" + q1
        resp = get_response(prompt)
        #print(prompt)
        #print(resp)
        #print("\n")
        if "yes" in resp.lower():
            new2revsplitlist[each] = 100
        else:
            new2revsplitlist[each] = 0
    return new2revsplitlist

def revanalysis(revsplits, revanalysis):
    revanalysis['Sub_Reviews'] = {}
    aspectlist = ["FOOD", "FLIGHT TIMING", "FLIGHT BOARDING", "FLIGHT BAGGAGE", "Flight CHECK IN", "AIRPORT_EXPERIENCE", 
                  "AIRPLANE EXPERIENCE", "FLIGHT SERVICE", "LOYALTY PROGRAM"]
    #Touchpoints in place of Aspects
    #Dont call out anything which look like maintainable
    # Business OP vs Technical OP
    new2revsplitlist = rev_splits(revsplits)
    
    for each1 in new2revsplitlist.keys():
        revanalysis['Sub_Reviews'][each1] = {}
        revanalysis['Sub_Reviews'][each1]['Aspects'] = []
        revanalysis['Sub_Reviews'][each1]['Sentiment Score'] = 0
        if new2revsplitlist[each1] == 0:
            revanalysis['Sub_Reviews'][each1]['Aspects'].append("Others")
            revanalysis['Sub_Reviews'][each1]['Sentiment Score'] = 0
            continue
        aspecttagged = 0
        for each2 in aspectlist:
            prompt = "'" + each1 + "'" + "\n" + q5
            prompt = prompt.replace("ASPECT", each2)
            resp = get_response(prompt)
            #print(prompt)
            #print(resp)
            #print("\n")
            if "yes" in resp.lower():
                # IDENTIFYING SENTIMENT SCORE
                sentscore = assign_sentiment_score(sentexamplelist, sentoutputlist, each1)
                revanalysis['Sub_Reviews'][each1]['Aspects'].append(each2)
                revanalysis['Sub_Reviews'][each1]['Sentiment Score'] = sentscore
                aspecttagged = 1
        if aspecttagged == 0:
            # IDENTIFYING SENTIMENT SCORE
            sentscore = assign_sentiment_score(sentexamplelist, sentoutputlist, each1)
            revanalysis['Sub_Reviews'][each1]['Aspects'].append("No Category")
            revanalysis['Sub_Reviews'][each1]['Sentiment Score'] = sentscore
    return revanalysis

def process_review(review):
    op = {}
    op['review'] = review
    if len(review) < 20:
        flag = is_it_a_review(review)
        op['is_review'] = flag
        if flag == "NO":
            op['sentiment_score'] = 0
            return op
    op['is_review'] = "Yes"
    op['sentiment_score'] = assign_sentiment_score(sentexamplelist, sentoutputlist, review)
    review = remove_typos(review)
    review = resolve_coreference_resolution(review)
    revssplits = sentence_splitting(review)
    finalop = revanalysis(revssplits, op)
    return finalop

def generate_response(input_text):
    try:
        global llm
        os.environ['OPENAI_API_KEY'] = openai_api_key
        #llm = OpenAI(model_name='gpt-4', temperature=0.9, openai_api_key=openai_api_key)
        llm = ChatOpenAI(model="gpt-4", temperature=0.2, logprobs=True)
        if input_text in revdata.keys():
            response = revdata[input_text]['op1']
        else:
            response = process_review(input_text)
        if response['is_review'] == "NO":
            st.write("The above text is NOT A REVIEW")
            st.write("\n\n\nSentiment Score: 0")
        else:
            st.write("The above text is A REVIEW\n\n")
            st.write("Sentiment Score: ", str(response['sentiment_score']))
            st.write("\n\n\n\nSub Sentences:\n\n")
            for i,each in enumerate(response['Sub_Reviews'].keys()):
                st.write(str(i+1) + ". " + each)
                st.write("Touchpoints Tagged: ", response['Sub_Reviews'][each]['Aspects'])
                st.write("Sentiment Score: ", int(response['Sub_Reviews'][each]['Sentiment Score']))
                st.write("\n\n")
    except Exception as e:
        st.error(f"An error occurred: {str(e)}")
        
def questions_and_comparisons(input_text):
    try:
        global llm
        os.environ['OPENAI_API_KEY'] = openai_api_key
        #llm = OpenAI(model_name='gpt-4', temperature=0.9, openai_api_key=openai_api_key)
        llm = ChatOpenAI(model="gpt-4", temperature=0.2, logprobs=True)
        if input_text in revdata.keys():
            response1 = revdata[input_text]['op2']['questions']
            response2 = revdata[input_text]['op2']['comparisons']
            st.write(response1)
            st.write("\n\n")
            st.write(response2)
        else:
            response1 = contains_questions(input_text)
            response2 = contains_comparisons(input_text)
            if response1 == "NO":
                response1 = "No Questions Found !!"
            if response2 == "NO":
                response2 = "No Comparisons Found !!"
            response1 = response1.replace("YES", "Questions: ")
            response2 = response2.replace("YES", "Comparisons: ")
            st.write(response1)
            st.write("\n\n")
            st.write(response2)
    except Exception as e:
        st.error(f"An error occurred: {str(e)}")

    
with st.form('my_form'):
    text = st.text_area('Enter your flight review:', '')
    submitted1 = st.form_submit_button('Sentences & Sentiment Scores')
    submitted2 = st.form_submit_button('Questions & Comparisons')
    if not openai_api_key.startswith('sk-'):
        st.warning('Please enter your OpenAI API key!', icon='⚠')
    if submitted1 and openai_api_key.startswith('sk-'):
        generate_response(text)
    if submitted2 and openai_api_key.startswith('sk-'):
        questions_and_comparisons(text)
